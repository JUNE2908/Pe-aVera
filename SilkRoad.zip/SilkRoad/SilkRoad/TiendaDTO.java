/**
 * Usado para desacoplar las vistas durante el renderizado.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class TiendaDTO {
    private final int id;
    private final int localizacion;
    private final String color;
    private final int stock;

    public TiendaDTO(int id, int localizacion, String color, int stock) {
        this.id = id;
        this.localizacion = localizacion;
        this.color = color;
        this.stock = stock;
    }

    public int getId() { return id; }
    public int getLocalizacion() { return localizacion; }
    public String getColor() { return color; }
    public int getStock() { return stock; }
}

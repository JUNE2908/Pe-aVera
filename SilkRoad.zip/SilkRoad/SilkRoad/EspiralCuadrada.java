import java.util.*;
/**
 * Asigna ubicaciones a celdas de una espiral cuadrada estable.
 * Entrega posiciones de dibujo en píxeles 
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class EspiralCuadrada {
    private final int W = 800, H = 300;
    private final int cx = W / 2, cy = H / 2;
    private final int cell = 26;

    private final Map<Integer, Posicion> mapa = new HashMap<>();
    private final Deque<Posicion> libres = new ArrayDeque<>();

    private int sx = 0, sy = 0;
    private int dir = 0;
    private int legLen = 1;
    private int legProg = 0;
    private int legsDone = 0;
    private boolean centerDone = false;

    public EspiralCuadrada(int radio) { }

    private Posicion cellToPix(int x, int y) { return new Posicion(cx + x * cell, cy + y * cell); }

    private Posicion nextCell() {
        if (!centerDone) { centerDone = true; return cellToPix(0, 0); }
        if (legProg == legLen) { dir = (dir + 1) % 4; legProg = 0; legsDone++; if (legsDone == 2) { legLen++; legsDone = 0; } }
        if (dir == 0) sx++; else if (dir == 1) sy++; else if (dir == 2) sx--; else sy--;
        legProg++;
        return cellToPix(sx, sy);
    }

    public void definirUbicaciones(int[] locs) {
        Set<Integer> actuales = new HashSet<>();
        for (int v : locs) actuales.add(v);

        Iterator<Map.Entry<Integer, Posicion>> it = mapa.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Posicion> e = it.next();
            if (!actuales.contains(e.getKey())) { libres.addFirst(e.getValue()); it.remove(); }
        }
        for (int v : actuales) {
            if (!mapa.containsKey(v)) {
                Posicion pos = !libres.isEmpty() ? libres.removeFirst() : nextCell();
                mapa.put(v, pos);
            }
        }
    }

    public Posicion aPosicion(int loc) {
        Posicion p = mapa.get(loc);
        if (p == null) p = cellToPix(0,0);
        return p;
    }
}
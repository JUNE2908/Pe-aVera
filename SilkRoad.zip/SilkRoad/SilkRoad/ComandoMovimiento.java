/**
 * Comando de movimiento con delta en X (dx) y un dy opcional.
 * En el simulador se usa dx para desplazar robots paso a paso.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class ComandoMovimiento {
    private final int dx;
    private final int dy;

    public ComandoMovimiento(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    public int dx() { return dx; }
    public int dy() { return dy; }
}

/**
 * DTO inmutable de Robot con id, localización y color.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class RobotDTO {
    private final int id;
    private final int localizacion;
    private final String color;

    public RobotDTO(int id, int localizacion, String color) {
        this.id = id;
        this.localizacion = localizacion;
        this.color = color;
    }

    public int getId() { return id; }
    public int getLocalizacion() { return localizacion; }
    public String getColor() { return color; }
}

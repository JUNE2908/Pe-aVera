/**
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class Posicion {
    private final int x, y;

    public Posicion(int x, int y) {
        this.x = x; this.y = y;
    }

    public int x() { return x; }
    public int y() { return y; }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Posicion)) return false;
        Posicion p = (Posicion) o;
        return this.x == p.x && this.y == p.y;
    }
}

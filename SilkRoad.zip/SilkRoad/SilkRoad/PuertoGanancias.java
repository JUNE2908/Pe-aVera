/**
 * Puerto para consultar el avance de ganancias como fracción 0..1.
 * Permite bajar la barra de progreso del modelo concreto de cálculo de ganancias.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public interface PuertoGanancias {
    double razon();
}

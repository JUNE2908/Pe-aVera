/**
 * Adaptador entre el modelo SilkRoad y el PuertoGanancias.
 * Realiza una operacion usando la ganancia actual y el capital restante en tiendas.
 *
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class AdaptadorGananciasSilkRoad implements PuertoGanancias {
    private final SilkRoad ruta;

    public AdaptadorGananciasSilkRoad(SilkRoad ruta) {
        this.ruta = ruta;
    }

    public double razon() {
        int[][] st = ruta.stores();
        long restante = 0;
        for (int i = 0; i < st.length; i++) restante += Math.max(0, st[i][1]);
        long ganado = Math.max(0, ruta.currentProfit());
        long denom = ganado + restante;
        if (denom <= 0) return 0.0;
        double r = (double)ganado / (double)denom;
        if (r < 0) r = 0;
        if (r > 1) r = 1;
        return r;
    }
}

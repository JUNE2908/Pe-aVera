/**
 * Barra de progreso de ganancias dibujada como rectángulo horizontal.
 * Lee la razón del PuertoGanancias y ajusta su ancho manteniéndose visible permanentemente.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class VistaBarraGananciaExtRectangle {
    private final PuertoGanancias ganancias;
    private final Rectangle bar;
    private int currentX = 70, currentY = 15;
    private final int x0 = 20, y0 = 270;

    public VistaBarraGananciaExtRectangle(PuertoGanancias ganancias) {
        this.ganancias = ganancias;
        this.bar = new Rectangle();
        this.bar.changeColor("green");
        this.bar.changeSize(10, 1);
        this.bar.makeVisible();
        bar.moveHorizontal(x0 - currentX); currentX = x0;
        bar.moveVertical(y0 - currentY);   currentY = y0;
    }

    public void actualizar() {
        int maxWidth = 760;
        int width = (int)Math.round(ganancias.razon() * maxWidth);
        if (width < 1) width = 1;
        bar.changeSize(10, width);
    }

    public void ocultar() { bar.makeInvisible(); }
}

/**
 * crea y renderiza vistas de tiendas, robots y la barra.
 * Reconstruye vistas por cuadro para mantener consistencia visual y manejar cambios de orden o cantidad.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class VistaLienzo {
    private VistaTiendaExtRectangle[] tiendaViews = new VistaTiendaExtRectangle[0];
    private VistaRobotExtCircle[]     robotViews  = new VistaRobotExtCircle[0];
    private final VistaBarraGananciaExtRectangle barra;

    public VistaLienzo(PuertoGanancias port){
        Canvas.getCanvas().setVisible(true);
        this.barra = new VistaBarraGananciaExtRectangle(port);
    }

    public void renderizar(TiendaDTO[] tiendas, RobotDTO[] robots, EspiralCuadrada espiral){
        for (int i = 0; i < tiendaViews.length; i++) {
            if (tiendaViews[i] != null) tiendaViews[i].ocultar();
        }
        for (int i = 0; i < robotViews.length; i++) {
            if (robotViews[i] != null) robotViews[i].ocultar();
        }

        tiendaViews = new VistaTiendaExtRectangle[tiendas.length];
        for (int i = 0; i < tiendas.length; i++) {
            tiendaViews[i] = new VistaTiendaExtRectangle(tiendas[i], espiral);
            tiendaViews[i].actualizar(espiral);
        }

        robotViews = new VistaRobotExtCircle[robots.length];
        for (int j = 0; j < robots.length; j++) {
            robotViews[j] = new VistaRobotExtCircle(robots[j], espiral);
            robotViews[j].actualizar(espiral);
        }

        barra.actualizar();
        Canvas.getCanvas().setVisible(true);
    }

    public void establecerVisible(boolean v){
        Canvas.getCanvas().setVisible(v);
    }

    public void mostrarError(String mensaje){
        javax.swing.JOptionPane.showMessageDialog(
            null, mensaje, "Error", javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }
}

/**
 * conecta el modelo SilkRoad con las vistas.
 * Mantiene mapas, gestiona creación/eliminación y movimientos para pruebas en BlueJ.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class Simulator {
    private SilkRoad ruta;
    private boolean visible = false;
    private VistaLienzo VistaLienzo;
    private MapeadorMatriz mapeador;
    private EspiralCuadrada espiral;
    private AdaptadorGananciasSilkRoad adaptadorGanancias;

    private static final int MAX = 1000;

    private final int[] storeIds   = new int[MAX];
    private final int[] storeLocs  = new int[MAX];
    private int storeCount = 0;

    private final int[] robotIds     = new int[MAX];
    private final int[] robotLocs    = new int[MAX];
    private final int[] robotStarts  = new int[MAX];
    private int robotCount = 0;

    public void crearRuta(int longitudIgnorado){
        ruta = new SilkRoad();
        espiral = new EspiralCuadrada(20);
        mapeador = new MapeadorMatriz();
        adaptadorGanancias = new AdaptadorGananciasSilkRoad(ruta);
        VistaLienzo = new VistaLienzo(adaptadorGanancias);
        if (visible) VistaLienzo.establecerVisible(true);
        renderizar();
    }

    public void agregarTienda(int id, int inicio, int stock){
        if (ruta == null) return;
        ruta.returnRobots();
        ruta.resupplyStores();
        ruta.placeStore(inicio, stock);
        if (ruta.ok()) {
            storeIds[storeCount]  = id;
            storeLocs[storeCount] = inicio;
            storeCount++;
            renderizar();
        } else if (VistaLienzo != null){
            VistaLienzo.mostrarError("No se pudo agregar tienda en "+inicio);
        }
    }

    public void eliminarTienda(int id){
        if (ruta == null) return;
        int idx = indexOf(storeIds, storeCount, id);
        if (idx != -1) {
            ruta.removeStore(storeLocs[idx]);
            for (int j = idx + 1; j < storeCount; j++) {
                storeIds[j-1]  = storeIds[j];
                storeLocs[j-1] = storeLocs[j];
            }
            storeCount--;
            renderizar();
        } else if (VistaLienzo != null){
            VistaLienzo.mostrarError("Tienda id="+id+" no encontrada");
        }
    }

    public void reabastecerTiendas(){
        if (ruta == null) return;
        ruta.resupplyStores();
        renderizar();
    }

    public void agregarRobot(int id, int inicio){
        if (ruta == null) return;
        ruta.returnRobots();
        ruta.resupplyStores();
        ruta.placeRobot(inicio);
        if (ruta.ok()) {
            robotIds[robotCount]    = id;
            robotStarts[robotCount] = inicio;
            robotLocs[robotCount]   = inicio;
            robotCount++;
            renderizar();
        } else if (VistaLienzo != null){
            VistaLienzo.mostrarError("No se pudo agregar robot en "+inicio);
        }
    }

    public void eliminarRobot(int id){
        if (ruta == null) return;
        int idx = indexOf(robotIds, robotCount, id);
        if (idx != -1) {
            ruta.removeRobot(robotLocs[idx]);
            for (int j = idx + 1; j < robotCount; j++) {
                robotIds[j-1]    = robotIds[j];
                robotStarts[j-1] = robotStarts[j];
                robotLocs[j-1]   = robotLocs[j];
            }
            robotCount--;
            renderizar();
        } else if (VistaLienzo != null){
            VistaLienzo.mostrarError("Robot id="+id+" no encontrado");
        }
    }

    public void retornarRobotsAlInicio(){
        if (ruta == null) return;
        ruta.returnRobots();
        for (int i = 0; i < robotCount; i++) robotLocs[i] = robotStarts[i];
        renderizar();
    }

    public void moverRobot(int id, ComandoMovimiento cmd){
        if (ruta == null) return;
        int idx = indexOf(robotIds, robotCount, id);
        if (idx == -1) {
            if (VistaLienzo != null) VistaLienzo.mostrarError("Robot id="+id+" no encontrado");
            return;
        }
        int dx = cmd.dx();
        int step = dx >= 0 ? 1 : -1;
        int pasos = Math.abs(dx);
        for (int t = 0; t < pasos; t++) {
            ruta.moveRobot(robotLocs[idx], step);
            if (!ruta.ok()) {
                if (VistaLienzo != null) VistaLienzo.mostrarError("No se pudo mover robot id="+id);
                break;
            }
            long nueva = (long)robotLocs[idx] + step;
            if (nueva < 0) nueva = 0;
            robotLocs[idx] = (int)nueva;
            renderizar();
            Canvas.getCanvas().wait(20);
        }
    }


    public int reiniciarYObtenerProgreso(){
        if (ruta == null) return 0;
        int earned = ruta.reboot();
        for (int i = 0; i < robotCount; i++) robotLocs[i] = robotStarts[i];
        renderizar();
        return earned;
    }

    public void establecerVisible(boolean v){
        visible = v;
        if (VistaLienzo != null) VistaLienzo.establecerVisible(v);
    }

    public String obtenerInfoRuta(){
        if (ruta == null) return "ruta no creada";
        return "stores=" + ruta.stores().length + ", robots=" + ruta.robots().length;
    }

    public void finalizar(){
        if (VistaLienzo != null) VistaLienzo.establecerVisible(false);
    }

    public void renderizar(){
        if (ruta == null || VistaLienzo == null) return;
        ajustarEspiralPorUbicaciones();
        TiendaDTO[] tiendas = mapeador.aTiendas(ruta.stores());
        RobotDTO[]  robots  = mapeador.aRobots(ruta.robots());
        VistaLienzo.renderizar(tiendas, robots, espiral);
    }

    private void ajustarEspiralPorUbicaciones() {
        int[][] st = ruta.stores();
        int[][] rb = ruta.robots();
        int n = st.length + rb.length;
        int[] locs = new int[n];
        int idx = 0;
        for (int i=0;i<st.length;i++) locs[idx++] = st[i][0];
        for (int i=0;i<rb.length;i++) locs[idx++] = rb[i][0];
        if (n==0) locs = new int[]{0};
        espiral.definirUbicaciones(locs);
    }

    private int indexOf(int[] arr, int size, int value){
        for (int i = 0; i < size; i++) if (arr[i] == value) return i;
        return -1;
    }
}

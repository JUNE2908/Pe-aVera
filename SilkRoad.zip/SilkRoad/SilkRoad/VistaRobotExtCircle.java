/**
 * Vista de un Robot representado como círculo en el Canvas.
 * Actualiza su posición en función de la EspiralCuadrada y de la localización lógica del robot.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class VistaRobotExtCircle {
    private final RobotDTO robot;
    private final Circle circle;
    private int currentX;
    private int currentY;

    public VistaRobotExtCircle(RobotDTO robot, EspiralCuadrada espiral) {
        this.robot = robot;
        this.circle = new Circle();
        this.circle.changeColor(robot.getColor());
        this.circle.changeSize(14);
        this.circle.makeVisible();
        Posicion p = espiral.aPosicion(robot.getLocalizacion());
        this.currentX = 20;
        this.currentY = 15;
        circle.moveHorizontal(p.x() - currentX); currentX = p.x();
        circle.moveVertical(p.y() - currentY);   currentY = p.y();
    }

    public void actualizar(EspiralCuadrada espiral) {
        Posicion p = espiral.aPosicion(robot.getLocalizacion());
        circle.moveHorizontal(p.x() - currentX); currentX = p.x();
        circle.moveVertical(p.y() - currentY);   currentY = p.y();
    }

    public void ocultar() { circle.makeInvisible(); }
}

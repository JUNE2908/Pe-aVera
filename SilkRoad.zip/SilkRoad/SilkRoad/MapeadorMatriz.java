/**
 * Asigna identidades estables y colores por defecto para el renderizado en la vista.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class MapeadorMatriz {
    public TiendaDTO[] aTiendas(int[][] matriz){
        TiendaDTO[] out = new TiendaDTO[matriz.length];
        for (int i = 0; i < matriz.length; i++){
            int id  = matriz[i][0];
            int loc = matriz[i][0];
            int stk = matriz[i][1];
            out[i] = new TiendaDTO(id, loc, "blue", stk);
        }
        return out;
    }

    public RobotDTO[] aRobots(int[][] matriz){
        RobotDTO[] out = new RobotDTO[matriz.length];
        for (int i = 0; i < matriz.length; i++){
            int id  = matriz[i][0];
            int loc = matriz[i][0];
            out[i] = new RobotDTO(id, loc, "red");
        }
        return out;
    }
}

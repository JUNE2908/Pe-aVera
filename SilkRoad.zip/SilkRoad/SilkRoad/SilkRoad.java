
/**
 * 
 * se encarga del costo por metro, resurtido por día y reinicio; expone profit acumulado y estados de validez.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class SilkRoad {
    private static final int MAX = 200000;

    private boolean visible = false;
    private boolean lastOk = true;
    private int profit = 0;

    private int reloj = 0;
    private void tick() { reloj++; }

    private final int[] robotPositions = new int[MAX];
    private final int[] robotsStart    = new int[MAX];
    private final int[] llegada        = new int[MAX];
    private int CantRobots = 0;

    private final int[] storePositions = new int[MAX];
    private final int[] capitalInicial = new int[MAX];
    private final int[] capital        = new int[MAX];
    private int CantTiendas = 0;

    public SilkRoad() { }

    public void placeStore(int ubicacion, int tenges) {
        if (tenges < 0 || indexStore(ubicacion) != -1 || indexRobotAny(ubicacion) != -1) {
            lastOk = false; return;
        }
        int i = CantTiendas++;
        storePositions[i] = ubicacion;
        capitalInicial[i] = tenges;
        capital[i]        = tenges;
        lastOk = true;
    }

    public void removeStore(int ubicacion) {
        int i = indexStore(ubicacion);
        if (i == -1) { lastOk = false; return; }
        shiftLeftStore(i);
        CantTiendas--;
        lastOk = true;
    }

    public void resupplyStores() {
        for (int i = 0; i < CantTiendas; i++) capital[i] = capitalInicial[i];
        lastOk = true;
    }

    public void placeRobot(int ubicacion) {
        if (indexRobotByStart(ubicacion) != -1 || indexStore(ubicacion) != -1) {
            lastOk = false; return;
        }
        int i = CantRobots++;
        robotsStart[i]    = ubicacion;
        robotPositions[i] = ubicacion;
        tick(); llegada[i] = reloj;
        lastOk = true;
    }

    public void removeRobot(int ubicacion) {
        int idx = earliestRobotAt(ubicacion);
        if (idx == -1) idx = indexRobotByStart(ubicacion);
        if (idx == -1) { lastOk = false; return; }
        shiftLeftRobot(idx);
        CantRobots--;
        lastOk = true;
    }

    public void returnRobots() {
        for (int i = 0; i < CantRobots; i++) {
            robotPositions[i] = robotsStart[i];
            tick(); llegada[i] = reloj;
        }
        lastOk = true;
    }

    public void moveRobot(int ubicacion, int meters) {
        int idx = earliestRobotAt(ubicacion);
        if (idx == -1) { lastOk = false; return; }

        long dest = (long)robotPositions[idx] + (long)meters;
        if (dest < 0) dest = 0;

        robotPositions[idx] = (int)dest;
        profit -= Math.abs(meters);
        tick(); llegada[idx] = reloj;

        int s = indexStore(robotPositions[idx]);
        if (s != -1 && capital[s] > 0) {
            profit += capital[s];
            capital[s] = 0;
        }
        lastOk = true;
    }

    public int reboot() {
        int earned = profit;
        returnRobots();
        resupplyStores();
        profit = 0;
        lastOk = true;
        return earned;
    }

    public int[][] stores() {
        int[][] a = new int[CantTiendas][2];
        for (int i = 0; i < CantTiendas; i++) {
            a[i][0] = storePositions[i];
            a[i][1] = capital[i];
        }
        sortByColumn0(a);
        return a;
    }

    public int[][] robots() {
        int[][] a = new int[CantRobots][2];
        for (int i = 0; i < CantRobots; i++) {
            a[i][0] = robotPositions[i];
            a[i][1] = robotsStart[i];
        }
        sortByColumn0(a);
        return a;
    }

    public void makeVisible()   { visible = true;  lastOk = true; }
    public void makeInvisible() { visible = false; lastOk = true; }
    public void finish()        { lastOk = true; }
    public boolean ok()         { return lastOk; }
    public int currentProfit()  { return profit; }

    private int indexStore(int loc) {
        for (int i = 0; i < CantTiendas; i++) if (storePositions[i] == loc) return i;
        return -1;
    }

    private int indexRobotByStart(int loc) {
        for (int i = 0; i < CantRobots; i++) if (robotsStart[i] == loc) return i;
        return -1;
    }

    private int indexRobotAny(int loc) {
        for (int i = 0; i < CantRobots; i++) {
            if (robotsStart[i] == loc || robotPositions[i] == loc) return i;
        }
        return -1;
    }

    private int earliestRobotAt(int loc) {
        int best = -1, bestStamp = Integer.MAX_VALUE;
        for (int i = 0; i < CantRobots; i++) {
            if (robotPositions[i] == loc && llegada[i] < bestStamp) {
                best = i; bestStamp = llegada[i];
            }
        }
        return best;
    }

    private void shiftLeftStore(int k) {
        for (int i = k + 1; i < CantTiendas; i++) {
            storePositions[i - 1] = storePositions[i];
            capitalInicial[i - 1] = capitalInicial[i];
            capital[i - 1]        = capital[i];
        }
    }

    private void shiftLeftRobot(int k) {
        for (int i = k + 1; i < CantRobots; i++) {
            robotsStart[i - 1]    = robotsStart[i];
            robotPositions[i - 1] = robotPositions[i];
            llegada[i - 1]        = llegada[i];
        }
    }

    private void sortByColumn0(int[][] a) {
        for (int i = 1; i < a.length; i++) {
            int v0 = a[i][0], v1 = a[i][1], j = i - 1;
            while (j >= 0 && a[j][0] > v0) {
                a[j + 1][0] = a[j][0]; a[j + 1][1] = a[j][1]; j--;
            }
            a[j + 1][0] = v0; a[j + 1][1] = v1;
        }
    }
}

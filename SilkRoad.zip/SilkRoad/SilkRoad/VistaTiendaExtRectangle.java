/**
 * Vista de una Tienda representada como rectángulo en el Canvas.
 * Sincroniza su posición con la EspiralCuadrada según la localización de la tienda.
 * 
 * @author Juan Vera y Hildebrando Pena
 * @version 2025-09-07
 */

public class VistaTiendaExtRectangle {
    private final TiendaDTO tienda;
    private final Rectangle rect;
    private int currentX;
    private int currentY;

    public VistaTiendaExtRectangle(TiendaDTO tienda, EspiralCuadrada espiral) {
        this.tienda = tienda;
        this.rect = new Rectangle();
        this.rect.changeColor(tienda.getColor());
        this.rect.changeSize(12, 12);
        this.rect.makeVisible();
        Posicion p = espiral.aPosicion(tienda.getLocalizacion());
        this.currentX = 70;
        this.currentY = 15;
        rect.moveHorizontal(p.x() - currentX); currentX = p.x();
        rect.moveVertical(p.y() - currentY);   currentY = p.y();
    }

    public void actualizar(EspiralCuadrada espiral) {
        Posicion p = espiral.aPosicion(tienda.getLocalizacion());
        rect.moveHorizontal(p.x() - currentX); currentX = p.x();
        rect.moveVertical(p.y() - currentY);   currentY = p.y();
    }

    public void ocultar() { rect.makeInvisible(); }
}

